# covidinc
Modeling the COVID-19 pandemic in Python
